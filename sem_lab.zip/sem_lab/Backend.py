from flask import Flask, request, redirect, url_for, render_template

app = Flask(__name__)


# Route for handling the login page logic
@app.route('/login', methods=['GET', 'POST'])
def login():
    error = None
    if request.method == 'POST':
        if request.form['username'] != 'admin' or request.form['password'] != 'P@ssw0rd':
            error = 'Invalid Credentials. Please try again.'
        else:
            return redirect(url_for('tcwnkkccjjhynqhynlbfjxgyfvfywivm'))
    return render_template('login.html', error=error)

@app.route('/tcwnkkccjjhynqhynlbfjxgyfvfywivm')
def tcwnkkccjjhynqhynlbfjxgyfvfywivm():
    return render_template('home.html')


if __name__ == "__main__":
    app.run()